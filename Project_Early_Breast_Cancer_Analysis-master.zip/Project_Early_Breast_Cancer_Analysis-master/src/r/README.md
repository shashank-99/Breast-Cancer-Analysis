# Machine Learning Techniques on Breast Cancer Wisconsin Data Set

This serves as a sub-directory for the breast cancer project with all r related stuff. More info later
